//___FILEHEADER___

#import "YHAbstractViewController.h"

@interface ___FILEBASENAMEASIDENTIFIER___ : YHAbstractViewController

@end


